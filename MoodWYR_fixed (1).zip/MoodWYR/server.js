require("dotenv").config();

const express = require("express");
const OpenAI = require("openai");
const path = require("path");

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const apiKey = process.env.OPENAI_API_KEY;
const client = apiKey && apiKey !== "YOUR_API_KEY_HERE"
  ? new OpenAI({ apiKey })
  : null;

const analysisSchema = {
  type: "object",
  properties: {
    mood: { type: "string" },
    emoji: { type: "string" },
    confidence: { type: "string", enum: ["low", "medium", "high"] },
    insight: { type: "string" },
    activity: { type: "string" }
  },
  required: ["mood", "emoji", "confidence", "insight", "activity"],
  additionalProperties: false
};

app.post("/api/analyze", async (req, res) => {
  try {
    const { answers } = req.body || {};

    if (!Array.isArray(answers) || answers.length === 0) {
      return res.status(400).json({ error: "No answers provided." });
    }

    if (answers.some(a =>
      !a ||
      typeof a.question !== "string" ||
      typeof a.selected !== "string" ||
      typeof a.signal !== "string"
    )) {
      return res.status(400).json({ error: "Invalid answer data." });
    }

    if (!client) {
      return res.status(503).json({
        error: "AI is not configured. Add OPENAI_API_KEY to your .env file."
      });
    }

    const prompt = `
You are MoodSense, a friendly companion inside a Would You Rather game.

Look at the player's full set of choices below and pick out a broad,
non-clinical emotional read. Don't diagnose or guess at a mental health
condition, and don't claim certainty - these are game answers, not
psychological evidence. Keep the tone supportive, positive and age
appropriate.

Player answers:
${JSON.stringify(answers, null, 2)}

Respond with a short mood label, one emoji, a confidence level, one or two
friendly sentences, and one small positive activity suggestion.
`;

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      input: prompt,
      text: {
        format: {
          type: "json_schema",
          name: "mood_analysis",
          strict: true,
          schema: analysisSchema
        }
      }
    });

    if (!response.output_text) {
      throw new Error("The AI returned an empty response.");
    }

    let result;
    try {
      result = JSON.parse(response.output_text);
    } catch {
      return res.status(502).json({ error: "AI returned an invalid response." });
    }

    const safe = {
      mood: result.mood,
      emoji: result.emoji,
      confidence: result.confidence,
      insight: result.insight,
      activity: result.activity
    };

    res.json(safe);
  } catch (error) {
    console.error("MoodSense error:", error);

    if (error?.status === 401) {
      return res.status(502).json({ error: "Invalid OpenAI API key." });
    }

    if (error?.status === 429) {
      return res.status(503).json({ error: "AI rate limit reached. Please try again later." });
    }

    res.status(500).json({ error: "AI analysis failed. Please try again." });
  }
});

// Express 5 does not accept the old app.get("*") wildcard syntax.
// A regular expression matches every remaining GET route safely.
app.get(/.*/, (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`MoodWYR running at http://localhost:${PORT}`);
});
